//
//  FunctionMachineApp.swift
//  FunctionMachine
//
//  Created by Tom Phillips on 11/10/21.
//

import SwiftUI

@main
struct FunctionMachineApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
